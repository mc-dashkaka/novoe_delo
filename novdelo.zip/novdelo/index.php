<?php
require_once 'admin/db_config.php';

// Получение кейсов из базы данных
try {
    $stmt = $pdo->query("SELECT * FROM cases");
    $cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $cases = [];
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>УИФ "Новое Дело" - Разработка информационных систем</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700;800;900&family=Playfair+Display:wght@700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head>
<body>
    <canvas id="particles"></canvas>
    
    <!-- Навигация -->
    <nav class="navbar">
        <div class="container nav-container">
            <div class="logo">Новое Дело</div>
            <div class="nav-links">
                <a href="#home">Главная</a>
                <a href="#cases">Кейсы</a>
                <a href="#contact">Контакты</a>
            </div>
        </div>
    </nav>
    
    <!-- Главная-секция -->
    <section id="home" class="hero">
        <div class="container hero-content">
            <h1>Преобразуем идеи в цифровые решения</h1>
            <p>Разработка современных информационных систем для вашего бизнеса</p>
            <a href="#cases" class="btn btn-primary">Наши проекты</a>
        </div>
    </section>
    
    <!-- О компании -->
    <section class="about">
        <div class="container">
            <div class="section-title">
                <h2>Наш подход</h2>
            </div>
            <div class="approach-cards">
                <div class="card float">
                    <div class="card-icon">💡</div>
                    <h3>Инновации</h3>
                    <p>Используем передовые технологии для создания эффективных решений, которые опережают время</p>
                </div>
                <div class="card float" style="animation-delay: 0.5s;">
                    <div class="card-icon">🎯</div>
                    <h3>Фокус на результат</h3>
                    <p>Разрабатываем системы, которые решают конкретные бизнес-задачи и приносят измеримую пользу</p>
                </div>
                <div class="card float" style="animation-delay: 1s;">
                    <div class="card-icon">🤝</div>
                    <h3>Партнерство</h3>
                    <p>Работаем в тесном сотрудничестве с клиентами на всех этапах проекта</p>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Кейсы -->
    <section id="cases" class="cases">
        <div class="container">
            <div class="section-title">
                <h2>Наши кейсы</h2>
            </div>
            <div class="case-filters">
                <button class="filter-btn active">Все проекты</button>
                <button class="filter-btn">Корпоративные системы</button>
                <button class="filter-btn">Веб-приложения</button>
                <button class="filter-btn">Мобильные приложения</button>
                <button class="filter-btn">Интеграции</button>
            </div>
            <div class="case-grid">
                <?php foreach ($cases as $case): ?>
                    <div class="case-card" 
                        data-categories="<?= htmlspecialchars($case['categories']) ?>" 
                        data-title="<?= htmlspecialchars($case['title']) ?>" 
                        data-description="<?= htmlspecialchars($case['description']) ?>">
                            <div class="case-image">
                                <img src="<?= htmlspecialchars($case['image_url']) ?>" alt="<?= htmlspecialchars($case['title']) ?>">
                            </div>
                         <div class="case-content">
                            <div class="case-tags">
                                <?php 
                                    $tags = explode(',', $case['tags']);
                                    foreach ($tags as $tag): 
                                        $tag = trim($tag);
                                        if (!empty($tag)):
                                ?>
                                <span class="case-tag"><?= htmlspecialchars($tag) ?></span>
                                <?php 
                                    endif;
                                    endforeach; 
                                ?>
                            </div>
                                <h3><?= htmlspecialchars($case['title']) ?></h3>
                                <p><?= htmlspecialchars($case['description']) ?></p>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    
    <!-- Контакты -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="section-title">
                <h2>Наши контакты</h2>
            </div>
            <div class="contact-grid">
                <div class="contact-info">
                    <div class="contact-item">
                        <div class="contact-icon">📍</div>
                        <div class="contact-text">
                            <h4>Адрес</h4>
                            <p>г. Барнаул, пр. Комсомольский, 100</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">📞</div>
                        <div class="contact-text">
                            <h4>Телефон</h4>
                            <p>+7 (3852) 55-55-55</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">✉️</div>
                        <div class="contact-text">
                            <h4>Email</h4>
                            <p>novoe_delo@brn.ru</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">⏱️</div>
                        <div class="contact-text">
                            <h4>Часы работы</h4>
                            <p>Пн-Пт: 9:00 - 18:00</p>
                        </div>
                    </div>
                </div>
                <div class="map-container">
                    <div id="map">
                        <div class="map-placeholder">
                            <p>УИФ "Новое Дело"<br>пр. Комсомольский, 100</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!-- Подвал -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-logo">УИФ "Новое Дело"</div>
                <p>Разработка информационных систем нового поколения</p>
                <div class="social-links">
                    <a href="#" class="social-icon"><i class="fab fa-vk"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-telegram"></i></a>
                    <a href="#" class="social-icon"><i class="fab fa-github"></i></a>
                </div>
                <div class="copyright">
                   <a href="admin/admin.php">&copy; 2025 mc dashkaka</a>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Онлайн-чат -->
    <div class="chat-toggle" id="chatToggle">
        <i class="fas fa-comments"></i>
        <div class="notification">1</div>
    </div>
    
    <div class="chat-container" id="chatContainer">
        <div class="chat-header" id="chatHeader">
            <h3>Чат поддержки</h3>
            <i class="fas fa-times" id="closeChat"></i>
        </div>
        <div class="chat-body">
            <div class="chat-messages" id="chatMessages">
                <div class="message bot-message">
                    Здравствуйте! Я виртуальный помощник компании УИФ "Новое Дело". Чем могу помочь?
                    <div class="message-time">10:45</div>
                </div>
                <div class="message bot-message">
                    Вы можете задать вопрос о наших услугах, кейсах или запросить консультацию.
                    <div class="message-time">10:45</div>
                </div>
                <div class="typing-indicator" id="typingIndicator">
                    Сотрудник печатает<span>.</span><span>.</span><span>.</span>
                </div>
            </div>
            <div class="chat-input">
                <input type="text" id="messageInput" placeholder="Напишите сообщение...">
                <button id="sendMessage">
                    <i class="fas fa-paper-plane"></i>
                </button>
            </div>
            <div class="chat-status">
                <div class="status-indicator"></div>
                <span>Онлайн, отвечаем в течение 5 минут</span>
            </div>
        </div>
    </div>
    
    <script>
        // Инициализация канваса для частиц
        const canvas = document.getElementById('particles');
        const ctx = canvas.getContext('2d');
        
        // Установка размеров канваса
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        
        // Массив частиц
        const particles = [];
        const particleCount = 150;
        
        // Создание частиц
        for (let i = 0; i < particleCount; i++) {
            particles.push({
                x: Math.random() * canvas.width,
                y: Math.random() * canvas.height,
                size: Math.random() * 3 + 1,
                speedX: Math.random() * 1 - 0.5,
                speedY: Math.random() * 1 - 0.5
            });
        }
        
        // Функция отрисовки частиц
        function drawParticles() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(particle => {
                ctx.beginPath();
                ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
                ctx.fillStyle = 'rgba(0, 255, 234, 0.15)';
                ctx.fill();
                
                // Обновление позиции
                particle.x += particle.speedX;
                particle.y += particle.speedY;
                
                // Обработка границ
                if (particle.x <= 0 || particle.x >= canvas.width) particle.speedX *= -1;
                if (particle.y <= 0 || particle.y >= canvas.height) particle.speedY *= -1;
            });
            
            requestAnimationFrame(drawParticles);
        }
        
        // Запуск анимации
        drawParticles();
        
        // Обработка изменения размера окна
        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });
        
        // Плавная прокрутка
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
        
        // Фильтрация кейсов
        const filterButtons = document.querySelectorAll('.filter-btn');
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                filterButtons.forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
            });
        });
        
        // Инициализация карты
        function initMap() {
            // Координаты офиса компании
            const officeCoords = [53.345903, 83.788130]; 
            
            // Создание карты
            const map = L.map('map').setView(officeCoords, 16);
            
            // Добавление слоя карты (темная тема)
            L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
                maxZoom: 20
            }).addTo(map);
            
            // Создание кастомного маркера
            const customIcon = L.divIcon({
                className: 'custom-marker',
                iconSize: [40, 40],
                iconAnchor: [20, 40]
            });
            
            // Добавление маркера
            const marker = L.marker(officeCoords, {icon: customIcon}).addTo(map);
            
            // Добавление всплывающего окна
            marker.bindPopup(`
                <div style="font-weight: bold; margin-bottom: 5px;">УИФ "Новое Дело"</div>
                <div>пр. Комсомольский, 100</div>
                <div style="margin-top: 10px;">Разработка информационных систем</div>
            `).openPopup();
            
            // Улучшение отображения карты на мобильных устройствах
            map.touchZoom.enable();
            map.scrollWheelZoom.enable();
        }
        
        // Инициализация карты после загрузки страницы
        window.addEventListener('load', initMap);
        
        // Функционал онлайн-чата
        const chatToggle = document.getElementById('chatToggle');
        const chatContainer = document.getElementById('chatContainer');
        const closeChat = document.getElementById('closeChat');
        const chatHeader = document.getElementById('chatHeader');
        const chatMessages = document.getElementById('chatMessages');
        const messageInput = document.getElementById('messageInput');
        const sendMessage = document.getElementById('sendMessage');
        const typingIndicator = document.getElementById('typingIndicator');
        const notification = document.querySelector('.notification');

        // Открыть/закрыть чат
        chatToggle.addEventListener('click', () => {
            chatContainer.classList.add('open');
            notification.style.display = 'none';
        });

        closeChat.addEventListener('click', (e) => {
            e.stopPropagation();
            chatContainer.classList.remove('open');
        });

        // Закрытие чата при клике на заголовок
        chatHeader.addEventListener('click', (e) => {
            if (e.target === chatHeader) {
                chatContainer.classList.remove('open');
            }
        });

        // Отправка сообщения
        sendMessage.addEventListener('click', sendUserMessage);
        messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendUserMessage();
            }
        });

        function sendUserMessage() {
            const message = messageInput.value.trim();
            if (message) {
                // Добавление сообщения пользователя
                addMessage(message, 'user');
                messageInput.value = '';
                
                // Имитация ответа бота
                setTimeout(() => {
                    typingIndicator.style.display = 'block';
                    setTimeout(() => {
                        typingIndicator.style.display = 'none';
                        addBotResponse(message);
                    }, 2000);
                }, 500);
            }
        }

        function addMessage(text, sender) {
            const messageElement = document.createElement('div');
            messageElement.classList.add('message');
            messageElement.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
            
            const now = new Date();
            const timeString = `${now.getHours()}:${now.getMinutes().toString().padStart(2, '0')}`;
            
            messageElement.innerHTML = `
                ${text}
                <div class="message-time">${timeString}</div>
            `;
            
            chatMessages.appendChild(messageElement);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        function addBotResponse(userMessage) {
            const responses = [
                "Спасибо за ваш вопрос! Наши специалисты свяжутся с вами в ближайшее время.",
                "Отличный вопрос! Мы можем предложить вам консультацию по этому вопросу.",
                "Мы специализируемся на разработке подобных систем. Расскажите подробнее о вашем проекте?",
                "Для уточнения деталей, пожалуйста, позвоните нам по телефону +7 (495) 123-45-67.",
                "Мы уже разрабатывали похожие решения. Могу показать вам наши кейсы?",
                "Благодарим за обращение! Наша команда экспертов рассмотрит ваш запрос.",
                "Мы можем запланировать онлайн-встречу для обсуждения вашего проекта. Удобное для вас время?"
            ];
            
            // Выбор случайного ответа
            const randomIndex = Math.floor(Math.random() * responses.length);
            addMessage(responses[randomIndex], 'bot');
        }

        // Показать уведомление о новом сообщении через 20 секунд
        setTimeout(() => {
            if (!chatContainer.classList.contains('open')) {
                notification.style.display = 'flex';
            }
        }, 20000);
    </script>
</body>
</html>