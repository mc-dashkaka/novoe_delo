<?php
session_start();

if (isset($_SESSION['admin_logged_in'])) {
    header('Location: admin.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    
    // Проверка учетных данных (в реальном приложении используйте хеширование!)
    if ($username === 'admin' && $password === 'secure_password') {
        $_SESSION['admin_logged_in'] = true;
        header('Location: admin.php');
        exit;
    } else {
        $error = 'Неверное имя пользователя или пароль';
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход в админ-панель</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        
        .login-container {
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
            width: 100%;
            max-width: 450px;
            padding: 40px 30px;
            animation: fadeIn 0.5s ease;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .login-logo {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .login-logo h2 {
            color: #1a1a2e;
            font-size: 24px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        
        .login-logo i {
            font-size: 28px;
            color: #1a1a2e;
        }
        
        .login-form .form-group {
            margin-bottom: 20px;
        }
        
        .login-form label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 15px;
        }
        
        .login-form input {
            width: 100%;
            padding: 14px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        .login-form input:focus {
            border-color: #1a1a2e;
            outline: none;
            box-shadow: 0 0 0 2px rgba(26, 26, 46, 0.2);
        }
        
        .btn-login {
            width: 100%;
            padding: 14px;
            background: #1a1a2e;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
            margin-top: 10px;
        }
        
        .btn-login:hover {
            background: #16213e;
        }
        
        .error-message {
            color: #f5222d;
            text-align: center;
            margin: 15px 0;
            font-size: 14px;
            padding: 10px;
            background: rgba(245, 34, 45, 0.1);
            border-radius: 4px;
        }
        
        /* Адаптивность */
        @media (max-width: 500px) {
            .login-container {
                padding: 30px 20px;
            }
            
            .login-logo h2 {
                font-size: 22px;
            }
            
            .login-form input {
                padding: 12px;
                font-size: 15px;
            }
            
            .btn-login {
                padding: 13px;
                font-size: 15px;
            }
        }
        
        @media (max-width: 360px) {
            .login-logo h2 {
                font-size: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-logo">
            <h2><i class="fas fa-lock"></i> Админ-панель</h2>
        </div>
        
        <?php if ($error): ?>
            <div class="error-message"><?= $error ?></div>
        <?php endif; ?>
        
        <form class="login-form" method="POST">
            <div class="form-group">
                <label for="username">Имя пользователя</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Пароль</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <button type="submit" class="btn-login">Войти</button>
        </form>
    </div>
</body>
</html>