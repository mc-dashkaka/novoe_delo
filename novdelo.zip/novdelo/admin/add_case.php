<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

require_once 'db_config.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $description = $_POST['description'] ?? '';
    $categories = $_POST['categories'] ?? '';
    $tags = $_POST['tags'] ?? '';
    $image_url = $_POST['image_url'] ?? '';
    
    if (empty($title) || empty($description) || empty($categories) || empty($tags) || empty($image_url)) {
        $error = 'Все поля обязательны для заполнения';
    } else {
        try {
            $stmt = $pdo->prepare("INSERT INTO cases (title, description, categories, tags, image_url) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$title, $description, $categories, $tags, $image_url]);
            
            $_SESSION['message'] = 'Кейс успешно добавлен!';
            header('Location: admin.php');
            exit;
        } catch (PDOException $e) {
            $error = 'Ошибка при добавлении кейса: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Добавить новый кейс</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/case.css">
    </head>
<body>
    <div class="admin-container">
        <a href="admin.php" class="back-link"><i class="fas fa-arrow-left"></i> Назад к списку</a>
        
        <h1 class="page-title"><i class="fas fa-plus-circle"></i> Добавить новый кейс</h1>
        
        <?php if ($error): ?>
            <div class="error-message"><?= $error ?></div>
        <?php endif; ?>
        
        <div class="form-container">
            <form method="POST">
                <div class="form-group">
                    <label for="title">Название кейса</label>
                    <input type="text" id="title" name="title" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Описание</label>
                    <textarea id="description" name="description" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="categories">Категории (через запятую)</label>
                    <input type="text" id="categories" name="categories" required>
                    <div class="error-message">Пример: erp, integration, web</div>
                </div>
                
                <div class="form-group">
                    <label for="tags">Теги (через запятую)</label>
                    <input type="text" id="tags" name="tags" required>
                    <div class="error-message">Пример: ERP, Интеграция, Бизнес-процессы</div>
                </div>
                
                <div class="form-group">
                    <label for="image_url">URL изображения</label>
                    <input type="text" id="image_url" name="image_url" required>
                </div>
                
                <button type="submit" class="btn-submit">Добавить кейс</button>
            </form>
        </div>
    </div>
</body>
</html>