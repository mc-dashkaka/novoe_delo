<?php
session_start();

// Проверка авторизации
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

// Подключение к базе данных
require_once 'db_config.php';

// Обработка действий
if (isset($_GET['action'])) {
    switch ($_GET['action']) {
        case 'delete':
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("DELETE FROM cases WHERE id = ?");
            $stmt->execute([$id]);
            $_SESSION['message'] = 'Кейс успешно удален!';
            break;
    }
}

// Получение всех кейсов
$stmt = $pdo->query("SELECT * FROM cases");
$cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель - Управление кейсами</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Montserrat', sans-serif;
        }
        
        body {
            background: #f0f2f5;
            color: #333;
            line-height: 1.6;
        }
        
        .admin-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background: #1a1a2e;
            color: white;
            padding: 15px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            position: relative;
        }
        
        .admin-nav {
            display: flex;
            gap: 15px;
        }
        
        .admin-nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 4px;
            transition: background 0.3s;
        }
        
        .admin-nav a:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 24px;
            cursor: pointer;
        }
        
        .page-title {
            margin: 20px 0;
            font-size: 28px;
            color: #1a1a2e;
            text-align: center;
        }
        
        .message {
            padding: 10px;
            margin: 15px 0;
            border-radius: 4px;
            text-align: center;
        }
        
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .add-case-btn {
            display: inline-block;
            background: #1a1a2e;
            color: white;
            padding: 10px 20px;
            border-radius: 4px;
            text-decoration: none;
            margin-bottom: 20px;
            transition: background 0.3s;
            font-size: 16px;
        }
        
        .add-case-btn:hover {
            background: #16213e;
        }
        
        .add-case-btn i {
            margin-right: 8px;
        }
        
        /* Мультиколоночная сетка для ПК */
        .cases-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .case-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .case-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.12);
        }
        
        .case-image {
            height: 180px;
            overflow: hidden;
        }
        
        .case-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }
        
        .case-card:hover .case-image img {
            transform: scale(1.05);
        }
        
        .case-content {
            padding: 20px;
        }
        
        .case-title {
            font-size: 18px;
            margin-bottom: 10px;
            color: #1a1a2e;
            line-height: 1.4;
        }
        
        .case-description {
            color: #555;
            margin-bottom: 15px;
            font-size: 14px;
            line-height: 1.5;
        }
        
        .case-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 6px;
            margin-bottom: 15px;
        }
        
        .case-tag {
            background: #e6f7ff;
            color: #1890ff;
            padding: 4px 8px;
            border-radius: 20px;
            font-size: 12px;
            white-space: nowrap;
        }
        
        .case-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-top: 15px;
        }
        
        .btn {
            padding: 8px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 5px;
            transition: all 0.3s;
            font-size: 14px;
        }
        
        .btn i {
            font-size: 14px;
        }
        
        .btn-edit {
            background: #1890ff;
            color: white;
            flex: 1;
            min-width: 120px;
            justify-content: center;
        }
        
        .btn-edit:hover {
            background: #096dd9;
        }
        
        .btn-delete {
            background: #f5222d;
            color: white;
            flex: 1;
            min-width: 120px;
            justify-content: center;
        }
        
        .btn-delete:hover {
            background: #cf1322;
        }
        
        /* Адаптивность */
        @media (max-width: 900px) {
            .admin-nav {
                display: none;
                position: absolute;
                top: 100%;
                right: 0;
                background: #1a1a2e;
                border-radius: 4px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.2);
                flex-direction: column;
                width: 200px;
                padding: 10px 0;
                z-index: 1000;
            }
            
            .admin-nav.show {
                display: flex;
            }
            
            .admin-nav a {
                padding: 12px 20px;
                border-radius: 0;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            /* Одна колонка для мобильных */
            .cases-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 600px) {
            .admin-container {
                padding: 15px;
            }
            
            .page-title {
                font-size: 24px;
            }
            
            .add-case-btn {
                width: 100%;
                text-align: center;
                padding: 12px;
            }
            
            .case-actions {
                flex-direction: column;
                gap: 8px;
            }
            
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="admin-header">
            <h2><i class="fas fa-cog"></i> Админ-панель</h2>
            <div class="admin-nav">
                <a href="admin.php"><i class="fas fa-table"></i> Кейсы</a>
                <a href="add_case.php"><i class="fas fa-plus"></i> Добавить кейс</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Выйти</a>
            </div>
        </div>
    </header>
    
    <div class="admin-container">
        <h1 class="page-title">Управление кейсами</h1>
        
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message success"><?= $_SESSION['message'] ?></div>
            <?php unset($_SESSION['message']); ?>
        <?php endif; ?>
        
        <a href="add_case.php" class="add-case-btn"><i class="fas fa-plus"></i> Добавить новый кейс</a>
        
        <div class="cases-grid">
            <?php foreach ($cases as $case): ?>
            <div class="case-card">
                <div class="case-image">
                    <img src="<?= htmlspecialchars($case['image_url']) ?>" alt="<?= htmlspecialchars($case['title']) ?>">
                </div>
                <div class="case-content">
                    <h3 class="case-title"><?= htmlspecialchars($case['title']) ?></h3>
                    <p class="case-description"><?= htmlspecialchars($case['description']) ?></p>
                    
                    <div class="case-tags">
                        <?php 
                        $tags = explode(',', $case['tags']);
                        foreach ($tags as $tag): 
                        ?>
                            <span class="case-tag"><?= htmlspecialchars(trim($tag)) ?></span>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="case-actions">
                        <a href="edit_case.php?id=<?= $case['id'] ?>" class="btn btn-edit">
                            <i class="fas fa-edit"></i> Редактировать
                        </a>
                        <a href="admin.php?action=delete&id=<?= $case['id'] ?>" class="btn btn-delete" 
                           onclick="return confirm('Вы уверены, что хотите удалить этот кейс?')">
                            <i class="fas fa-trash"></i> Удалить
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <script>
        // Мобильное меню
        document.addEventListener('DOMContentLoaded', function() {
            const menuBtn = document.querySelector('.mobile-menu-btn');
            if (menuBtn) {
                menuBtn.addEventListener('click', function() {
                    const nav = document.querySelector('.admin-nav');
                    nav.classList.toggle('show');
                });
            }
        });
    </script>
</body>
</html>